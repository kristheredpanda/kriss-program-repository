File name: 6969.exe
Creator: KrisTheRedPanda (on YouTube)
Creation Date: 13/12/2023
==============================================
This program contains malicious code so do not
run it your your real computer, only a virtual
machine.