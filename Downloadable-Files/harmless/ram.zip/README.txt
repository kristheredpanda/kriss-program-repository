this can run on an operating system as old as Windows 98 if you have .NET Framework 2.0 installed
===========================================
ram: a joke program made by Kris The Red Panda (https://ktrp.free.nf)